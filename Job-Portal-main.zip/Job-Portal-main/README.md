echo "# Job Portal Project

A web-based job portal built using Java Servlets, JSP, and MySQL.

## Features
- User Registration and Login
- Job Posting and Application
- Profile Management
- Admin Dashboard

## Technologies Used
- Java, JSP, Servlets
- HTML, CSS
- MySQL
- Apache Tomcat

" >> README.md

git add README.md
git commit -m "Added README"
git push
